# Maple Studio — fictional demonstration

FICTIONAL SAMPLE: no real client launch, public form submission, or email delivery has been verified. No deployment is performed by this command.

## Your files

- website-source/: editable source, build, check and local preview scripts.
- ready-to-host/: static files from the successful fresh-copy build; upload the contents to the agreed static host.
- docs/: editing, deployment, scope and service limitations.
- verification/: manifest, build/scan result and SHA-256 inventory.

## Edit and preview

Install Node.js 24 or newer. No dependency install is needed. Open website-source/ in your code editor. From that folder run:

```sh
node scripts/build.mjs
node scripts/check.mjs
node scripts/preview.mjs
```

Open http://127.0.0.1:4173 and use Ctrl+C to stop. Edit public/; rebuild before deploying. See website-source/README.md for full instructions. Python and Gitleaks are needed only by the studio's packaging command, not to edit, build, preview or host this delivered site.

The website package includes custom code, one initial launch, a source ZIP, two review rounds and the agreed 30-day defect correction. The signed scope controls price, page cap, creative scope and all terms. This archive creates no accounts or ongoing services. There is no bundled CMS/editor, portal, store, CRM, configured booking/newsletter account, tracking-number setup or scheduled growth follow-up.

Static source/build files are portable. Connected provider services, DNS, email, form endpoints, secrets, and accounts require separate setup or migration. The sample sends nothing. Automated checks and a clean scanner result do not guarantee the absence of every secret or replace browser and launch review.
