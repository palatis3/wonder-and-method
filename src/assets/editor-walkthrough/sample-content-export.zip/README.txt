Fictional Fieldwork sample content export, October 2026.
Content and media only. This is not a complete hosted site, authentication setup or deployment package.
The image path in the page content resolves from public/.
The source page and article were saved through Decap CMS 3.17.1 in an isolated local sample.
